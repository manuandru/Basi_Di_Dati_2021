CREATE TRIGGER CHANGE_QUANTITA_MATERIALI
ON DETTAGLI_MATERIALI 
AFTER INSERT
AS  
BEGIN 
    DECLARE @CodMateriale int;
    DECLARE @QuantitaUsata int;
    DECLARE @Quantita int;
    DECLARE @QuantitaVenduta int;

    SELECT @CodMateriale = CodMateriale FROM inserted;
    SELECT @QuantitaUsata = Quantita FROM inserted;
    SELECT @Quantita = Quantita FROM MATERIALI WHERE CodMateriale = @CodMateriale;
    SELECT @QuantitaVenduta = QuantitaVenduta FROM MATERIALI WHERE CodMateriale = @CodMateriale;

    /* UPDATE QUANTITA' IN MAGAZZINO */
    UPDATE MATERIALI
    SET Quantita = @Quantita - @QuantitaUsata
    WHERE CodMateriale = @CodMateriale

    /* UPDATE QUANTITA' VENDUTA */
    UPDATE MATERIALI
    SET QuantitaVenduta = QuantitaVenduta + @QuantitaUsata
    WHERE CodMateriale = @CodMateriale

END  
GO