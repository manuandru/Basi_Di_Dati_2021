INSERT INTO ELETTRICISTI VALUES
(<CodiceFiscale>, <Nome>, <Cognome>);

SELECT CodRuolo
FROM RUOLI
WHERE <condizioni>

INSERT INTO ELETTRICISTI_CON_RUOLI VALUES
(<DataInizioElettricista>, <DataFineElettricista>,
<CodiceFiscale>, <CodiceRuolo>);