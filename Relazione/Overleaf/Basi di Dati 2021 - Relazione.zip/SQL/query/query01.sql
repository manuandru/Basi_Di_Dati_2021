/* Privati */
INSERT INTO CLIENTI VALUES
(<CodCliente>, <Telefono>, <CodiceFiscale>, 
<Nome>, <Cognome>, NULL, NULL);

/* Aziende */
INSERT INTO CLIENTI VALUES
(<CodCliente>, <Telefono>, NULL, NULL, NULL, 
<PartitaIVA>, <Denominazione>);