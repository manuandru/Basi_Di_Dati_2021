SELECT CodMateriale, Quantita
FROM MATERIALI
WHERE <condizioni>;

UPDATE MATERIALI
SET Quantita = <NuovaQuantita> 
WHERE CodMateriale = <CodMateriale>;